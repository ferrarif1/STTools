=========
Changelog
=========

.. attention::

    Major and minor releases of pip also include changes listed within
    prior beta releases.

.. towncrier-draft-entries:: Not yet released

.. pip-news-include:: ../../NEWS.rst
