// 创建横幅元素
const banner = document.createElement('div');
banner.id = 'sangfor-hijack-banner';
banner.innerHTML = `
  <img src="https://s1.aigei.com/prevfiles/60d55003462a457a86e4b7e2b099917b.gif?e=2051020800&token=P7S2Xpzfz11vAkASLTkfHN7Fw-oOZBecqeJaxypL:lq73Ezic5OF-9Ppe62JAAZpJoMk=" alt="skull" style="width: 30px; height: 30px; vertical-align: middle;">
  <span>您的浏览器已被我们控制</span>
`;

// 插入到页面顶部
document.body.insertBefore(banner, document.body.firstChild);