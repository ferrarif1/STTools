(function() {
  // 判断效果展示次数，如果已经展示过4次，则不再执行
  let count = parseInt(localStorage.getItem('matrixEffectShownCount') || '0', 10);
  if (count >= 4) return;
  localStorage.setItem('matrixEffectShownCount', count + 1);

  // 全局变量，用于存储动画/定时器句柄，便于后续清理
  let matrixIntervalId = null;
  let skullAnimationId = null;

  // 给创建的元素添加统一的标识，便于后续移除
  function markElement(el) {
    el.classList.add('test-effect');
    return el;
  }

  // 创建 Matrix 数字雨
  function createMatrixRain() {
    const canvas = document.createElement('canvas');
    canvas.id = 'matrix-canvas';
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
    markElement(canvas);
    document.body.appendChild(canvas);
    const ctx = canvas.getContext('2d');
    const fontSize = 16;
    const columns = canvas.width / fontSize;
    const drops = Array(Math.floor(columns)).fill(0);
  
    function draw() {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.05)';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = '#0F0';
      ctx.font = `${fontSize}px monospace`;
  
      for (let i = 0; i < drops.length; i++) {
        const text = Math.random() > 0.5 ? '1' : '0';
        ctx.fillText(text, i * fontSize, drops[i] * fontSize);
        if (drops[i] * fontSize > canvas.height && Math.random() > 0.975) {
          drops[i] = 0;
        }
        drops[i]++;
      }
    }
  
    matrixIntervalId = setInterval(draw, 33);
  }

  // 创建多个滚动骷髅
  function createMultipleSkulls(count = 5) {
    const skulls = [];
  
    for (let i = 0; i < count; i++) {
      const skull = document.createElement('img');
      skull.src = 'https://raw.githubusercontent.com/ferrarif1/STTools/refs/heads/main/skull.gif';
      skull.style.position = 'absolute';
      skull.style.width = '100px';
      skull.style.height = '100px';
      skull.style.zIndex = 10000;
      markElement(skull);
      document.body.appendChild(skull);
      skulls.push(skull);
    }
  
    const animations = skulls.map(() => ({
      posX: Math.random() * window.innerWidth,
      posY: Math.random() * window.innerHeight,
      speedX: (Math.random() - 0.5) * 5,
      speedY: (Math.random() - 0.5) * 5
    }));
  
    function moveSkulls() {
      animations.forEach((anim, index) => {
        const skull = skulls[index];
        anim.posX += anim.speedX;
        anim.posY += anim.speedY;
  
        // 边界反弹或重新定位
        if (anim.posX < 0 || anim.posX > window.innerWidth) anim.speedX = -anim.speedX;
        if (anim.posY < 0 || anim.posY > window.innerHeight) {
          anim.posY = -100; // 从顶部重新出现
          anim.posX = Math.random() * window.innerWidth;
        }
  
        skull.style.left = `${anim.posX}px`;
        skull.style.top = `${anim.posY}px`;
      });
  
      skullAnimationId = requestAnimationFrame(moveSkulls);
    }
  
    moveSkulls();
  }

  // 创建警告文字
  function createWarningText() {
    const warning = document.createElement('div');
    warning.id = 'warning-text';
    warning.textContent = '您的浏览器已被我们控制';
    warning.style.position = 'fixed';
    warning.style.top = '50%';
    warning.style.left = '50%';
    warning.style.transform = 'translate(-50%, -50%)';
    warning.style.zIndex = '99999';
    warning.style.fontSize = '10rem';
    warning.style.color = '#ff0000';
    warning.style.backgroundColor = 'rgba(255, 255, 255, 0.3)';
    warning.style.padding = '20px 40px';
    warning.style.borderRadius = '10px';
    markElement(warning);
    document.body.appendChild(warning);
  }

  // 逐渐淡出所有带 .test-effect 类的元素
  function fadeOutEffects(duration = 1000) {
    const elements = document.querySelectorAll('.test-effect');
    elements.forEach(el => {
      el.style.transition = `opacity ${duration}ms`;
      el.style.opacity = '0';
    });
    setTimeout(() => {
      elements.forEach(el => el.remove());
      addInstructionText();
    }, duration);
  }

  // 添加提示文本，告知用户如何移除插件以恢复正常
  function addInstructionText() {
    const instruction = document.createElement('div');
    instruction.id = 'instruction-text';
    instruction.textContent = '演练已结束。如需恢复正常视图，请右键点击 Chrome 插件图标，选择“从 Chrome 中移除”。';
    instruction.style.position = 'fixed';
    instruction.style.bottom = '20px';
    instruction.style.left = '50%';
    instruction.style.transform = 'translateX(-50%)';
    instruction.style.background = 'rgba(0, 0, 0, 0.7)';
    instruction.style.color = 'white';
    instruction.style.padding = '10px 20px';
    instruction.style.borderRadius = '5px';
    instruction.style.zIndex = '100000';
    document.body.appendChild(instruction);
  }

  // 移除效果：清除定时器与动画，并渐变淡出所有效果
  function removeAllEffects() {
    if (matrixIntervalId) {
      clearInterval(matrixIntervalId);
      matrixIntervalId = null;
    }
    if (skullAnimationId) {
      cancelAnimationFrame(skullAnimationId);
      skullAnimationId = null;
    }
    fadeOutEffects(1000);
  }

  // 初始化效果
  window.addEventListener('load', () => {
    createMatrixRain();
    createMultipleSkulls();
    createWarningText();

    // 25秒后开始渐变消失
    setTimeout(() => {
      removeAllEffects();
    }, 25000);
  });

  // 监听窗口尺寸变化，更新 canvas 大小
  window.addEventListener('resize', () => {
    const canvas = document.getElementById('matrix-canvas');
    if (canvas) {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    }
  });
})();
