(function() {
  const HYPER_ANXIETY = {
      // 状态存储
      storage: {
          key: 'QuantumChannelStatus',
          get() {
              return JSON.parse(localStorage.getItem(this.key)) || { initialized: false }
          },
          set(val) {
              localStorage.setItem(this.key, JSON.stringify(val))
          }
      },

      // 危机视觉元素
      crisisElements: {
          quantumFlare: null,
          radiationPulse: null,
          emergencyStrobe: null
      },

      init() {
          this.injectCrisisCSS();
          this.createDoomsdayInterface();
          this.triggerQuantumInit();
          this.startAnxietyInducers();
      },

      // 注入动态危机样式
      injectCrisisCSS() {
          const style = document.createElement('style');
          style.textContent = `
              @keyframes pulse-apocalypse {
                  0% { opacity: 0.8; transform: scale(1); }
                  50% { opacity: 1; transform: scale(1.2); }
                  100% { opacity: 0.8; transform: scale(1); }
              }

              .quantum-flare {
                  position: fixed;
                  top: 0;
                  left: 0;
                  width: 100vw;
                  height: 100vh;
                  background: radial-gradient(circle, rgba(255,0,0,0.5) 0%, transparent 70%);
                  animation: pulse-apocalypse 0.8s infinite;
                  pointer-events: none;
                  z-index: 9998;
              }

              .radiation-pulse {
                  position: fixed;
                  border: 3px solid #ff0000;
                  border-radius: 50%;
                  filter: blur(10px);
                  animation: radiation-wave 1.2s infinite;
              }

              @keyframes radiation-wave {
                  from { transform: scale(0); opacity: 1; }
                  to { transform: scale(4); opacity: 0; }
              }
          `;
          document.head.appendChild(style);
      },

      // 创建末日接口
      createDoomsdayInterface() {
          const container = document.createElement('div');
          container.innerHTML = `
              <div class="quantum-flare"></div>
              <div id="crisisPanel" style="position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);z-index:9999;color:#ff0000;text-align:center;">
                  <div style="font-size:4rem;text-shadow:0 0 20px #ff0000;">⚠️</div>
                  <div id="crisisMessage" style="font-family:'Courier New',monospace;font-size:1.5rem;margin:20px 0;">
                      <span id="progressValue">0%</span> 量子通道初始化...
                  </div>
                  <div id="countdown" style="font-size:1.2rem;color:#ff8888;">
                      系统崩溃倒计时: <span>5:00</span>
                  </div>
              </div>
          `;
          document.body.appendChild(container);
      },

      // 触发量子初始化
      triggerQuantumInit() {
          const state = this.storage.get();
          if (state.initialized) {
              this.showCriticalFailure();
              return;
          }

          this.startHyperProgress(() => {
              this.storage.set({ initialized: true });
              this.detonateVisuals();
          });
      },

      // 启动高压进度
      startHyperProgress(onComplete) {
          let progress = 0;
          const crisisMessage = document.getElementById('crisisMessage');
          const valueDisplay = document.getElementById('progressValue');
          const panicPhrases = [
              "检测到量子纠缠异常",
              "反物质泄漏警告",
              "维度折叠失败",
              "时间线校准错误"
          ];

          const panicInterval = setInterval(() => {
              crisisMessage.innerHTML = `
                  ${progress}% ${panicPhrases[Math.floor(Math.random()*panicPhrases.length)]}
                  <div style="font-size:0.8em;color:#ff4444;">
                      [ERROR CODE: 0x${Math.random().toString(16).substr(2,8).toUpperCase()}]
                  </div>
              `;
          }, 800);

          const panicWave = setInterval(() => {
              const wave = document.createElement('div');
              wave.className = 'radiation-pulse';
              wave.style.left = `${Math.random()*100}%`;
              wave.style.top = `${Math.random()*100}%`;
              document.body.appendChild(wave);
              setTimeout(() => wave.remove(), 1200);
          }, 300);

          const updateProgress = () => {
              progress += Math.random() * 15;
              if (progress >= 100) {
                  clearInterval(panicInterval);
                  clearInterval(panicWave);
                  onComplete();
                  return;
              }
              
              valueDisplay.textContent = `${Math.min(100, Math.floor(progress))}%`;
              requestAnimationFrame(updateProgress);
          };

          requestAnimationFrame(updateProgress);
      },

      // 显示最终崩溃
      showCriticalFailure() {
          document.getElementById('crisisPanel').innerHTML = `
              <div style="font-size:3rem;text-shadow:0 0 30px #ff0000;">💥</div>
              <div style="font-size:1.5rem;margin:20px 0;">
                  量子超载！系统不可恢复
              </div>
              <div style="font-size:1rem;color:#ff8888;">
                  [核心温度: ${Math.floor(Math.random()*10000)}K]
              </div>
          `;
      },

      // 启动焦虑诱导器
      startAnxietyInducers() {
          // 视角抖动效果
          let shakeIntensity = 0;
          setInterval(() => {
              document.body.style.transform = `
                  translate(${Math.random()*shakeIntensity}px, ${Math.random()*shakeIntensity}px)
              `;
              shakeIntensity = Math.min(10, shakeIntensity + 0.1);
          }, 50);

          // 末日倒计时
          let seconds = 300;
          setInterval(() => {
              seconds--;
              document.querySelector('#countdown span').textContent = 
                  `${Math.floor(seconds/60)}:${String(seconds%60).padStart(2,'0')}`;
          }, 1000);
      },

      // 引爆视觉效果
      detonateVisuals() {
          setInterval(() => {
              document.body.style.background = `hsl(${Math.random()*360}, 70%, 5%)`;
          }, 100);

          const particles = Array(50).fill().map(() => {
              const p = document.createElement('div');
              p.style = `
                  position: fixed;
                  width: 2px;
                  height: 2px;
                  background: #ff0000;
                  pointer-events: none;
              `;
              document.body.appendChild(p);
              return p;
          });

          setInterval(() => {
              particles.forEach(p => {
                  p.style.left = `${Math.random()*100}%`;
                  p.style.top = `${Math.random()*100}%`;
                  p.style.transform = `scale(${Math.random()*3})`;
              });
          }, 100);
      }
  };

  // 启动系统
  HYPER_ANXIETY.init();
})();